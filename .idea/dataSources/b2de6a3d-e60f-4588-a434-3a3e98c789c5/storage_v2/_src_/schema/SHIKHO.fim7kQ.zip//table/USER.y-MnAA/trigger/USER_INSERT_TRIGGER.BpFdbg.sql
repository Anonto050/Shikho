create trigger USER_INSERT_TRIGGER
    after insert
    on "USER"
    for each row
DECLARE
    new_id NUMBER;
    new_name VARCHAR(100);
    new_email VARCHAR(1000);
    new_password VARCHAR(100);
    new_image VARCHAR(1000);
    new_type VARCHAR(20);
BEGIN
    new_id := :NEW.USER_ID;
    new_name := :NEW.NAME;
    new_email := :NEW.EMAIL;
    new_password := :NEW.PASSWORD;
    new_image := :NEW.IMAGE;
    new_type := :NEW.TYPE;

    DBMS_OUTPUT.PUT_LINE('User Insert Successful');
end;
/

