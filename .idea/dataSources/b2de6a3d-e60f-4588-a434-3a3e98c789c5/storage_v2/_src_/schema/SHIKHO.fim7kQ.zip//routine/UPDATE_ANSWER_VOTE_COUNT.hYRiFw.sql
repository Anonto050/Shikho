create FUNCTION UPDATE_ANSWER_VOTE_COUNT(answer_id IN NUMBER)
RETURN NUMBER IS
    curr_v_count NUMBER;
BEGIN
    curr_v_count := GET_ANSWER_VOTE_COUNT(answer_id);

    UPDATE FORUM_ANSWER_VOTE SET VOTE_COUNT = curr_v_count + 1
    WHERE FORUM_ANSWER_ID = answer_id;
    COMMIT;

    curr_v_count := GET_ANSWER_VOTE_COUNT(answer_id);

    RETURN curr_v_count;
end;
/

