create FUNCTION CONVERT_TO_DATE(string_date IN VARCHAR2)
RETURN DATE IS
     converted_date DATE;
BEGIN
    converted_date := TO_DATE(string_date, 'YYYY-MM-DD HH24:MI:SS');
    return converted_date;
end;
/

