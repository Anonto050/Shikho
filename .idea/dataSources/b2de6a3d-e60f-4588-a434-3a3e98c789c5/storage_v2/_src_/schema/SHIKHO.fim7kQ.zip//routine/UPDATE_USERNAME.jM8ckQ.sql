create FUNCTION UPDATE_USERNAME(user_name IN VARCHAR, u_id IN NUMBER)
RETURN VARCHAR IS
    new_name VARCHAR(1000);
BEGIN
    UPDATE "USER" SET NAME = user_name WHERE USER_ID = u_id;
    COMMIT;

    SELECT NAME INTO new_name FROM "USER" WHERE USER_ID = u_id;
    RETURN new_name;
end;
/

