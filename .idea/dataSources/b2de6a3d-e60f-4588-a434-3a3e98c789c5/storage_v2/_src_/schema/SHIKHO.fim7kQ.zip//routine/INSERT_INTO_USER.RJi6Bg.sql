create FUNCTION
    INSERT_INTO_USER(
        u_id IN NUMBER,
        user_name IN VARCHAR,
        mail IN VARCHAR,
        pass IN VARCHAR,
        img IN VARCHAR,
        user_type IN VARCHAR)
RETURN BOOLEAN IS
    success BOOLEAN;
BEGIN
    INSERT INTO "USER" (USER_ID, NAME, EMAIL, PASSWORD, IMAGE, "TYPE")
    VALUES (u_id, user_name, mail, pass, img, user_type);
    COMMIT;

    success := TRUE;
    RETURN success;
end;
/

