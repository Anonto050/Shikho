create FUNCTION UPDATE_QUESTION_VOTE_COUNT(question_id IN NUMBER)
RETURN NUMBER IS
    curr_v_count NUMBER;
BEGIN
    curr_v_count := GET_QUESTION_VOTE_COUNT(question_id);

    UPDATE FORUM_QUESTION_VOTE SET VOTE_COUNT = curr_v_count + 1
    WHERE FORUM_QUESTION_ID = question_id;
    COMMIT;

    curr_v_count := GET_QUESTION_VOTE_COUNT(question_id);

    RETURN curr_v_count;
end;
/

